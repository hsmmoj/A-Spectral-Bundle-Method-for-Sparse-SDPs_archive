function [semiOpt] = SemiOpt(data)



end